package com.example.recycelview;
public class Word {

    //the first string variable
    private String first ;

    // the seconed string variable
    private  String second ;

    public Word (String ftxt , String stxt) {
        first = ftxt ;
        second = stxt ;

    }

    public String get_ftxt ( ){
        return first ;

    }

    public  String get_stxt ( ){
        return  second ;

    }
}
