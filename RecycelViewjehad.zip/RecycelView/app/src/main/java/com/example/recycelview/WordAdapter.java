package com.example.recycelview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WordAdapter extends ArrayAdapter<Word> implements RecyclerView.RecyclerListener {

    public WordAdapter(MainActivity context, int list_item, ArrayList<Word>array ) {
        super(context, list_item, array);
    }

    public View getView(int posotion , View convertView , ViewGroup parent ){
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        Word text = getItem(posotion);

        TextView firstTextView = (TextView) listItemView.findViewById(R.id.first_text);
        firstTextView.setText(text.get_ftxt());

        TextView sec_textView = (TextView) listItemView.findViewById(R.id.second_text);
        sec_textView.setText(text.get_stxt());
        return listItemView ;
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder holder) {

    }
}
